class Book:
    def __init__(self, book_id, book_name, details, author):
        self.book_id = book_id
        self.book_name = book_name
        self.details = details
        self.author = author