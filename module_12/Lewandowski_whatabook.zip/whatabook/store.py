class Store:
    def __init__(self, store_id, locale):
        self.store_id = store_id
        self.locale = locale